using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class knowledgePanelInfo : MonoBehaviour
{
    public string KnowledgeNumber = null;
    public string KnowledgeInfo = null;
}
